<title>Index</title>
<strong>Modul 4</strong><br>

<?php
echo "<a href=oppgave_1.php target=_blank>Lenke til oppgave 1.</a><br>";
echo "<a href=oppgave_2.1.php target=_blank>Lenke til oppgave 2.</a><br>";
echo "<a href=oppgave_3.php target=_blank>Lenke til oppgave 3.</a><br>";
echo "<a href=oppgave_4.php target=_blank>Lenke til oppgave 4.</a><br>";
echo "<a href=oppgave_5.php target=_blank>Lenke til oppgave 5.</a><br>";
?>